width = 17
height = 12.0

# width/2
# Answer :- 8.5
# Type:- float

print(f"{width/2}")
print(type((width/2)))
print()

# width/2.0
# Answer :- 8.5
# Type:- float

print(f"{width/2.0}")
print(type((width/2.0)))
print()

# height/3
# Answer :- 4.0
# Type:- Float

print(f"{height/3}")
print(type((height/3)))
print()

# 1+2*5
# Answer :- 11
# Type:- int

print(f"{1+2*5}")
print(type(1+2*5))