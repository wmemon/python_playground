kingdoms = ['Bacteria', 'Protozoa', 'Chromista', 'Plantae', 'Fungi', 'Animalia']
print(kingdoms[0])
print(kingdoms[len(kingdoms)-1])
print(kingdoms[:3])
print(kingdoms[2:5])
print(kingdoms[4:len(kingdoms)])