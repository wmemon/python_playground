i=1
while i<=100:
    print(f" {i}",end=" ")
    if i%10==0:
        print()
    i += 1