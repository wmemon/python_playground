name = str(input("Please enter your name:- "))
print(f"Hello {name}")