hours = float(input("Enter hours:- "))
rate = float(input("Enter rate:- "))
print(f"Pay: {hours*rate}")