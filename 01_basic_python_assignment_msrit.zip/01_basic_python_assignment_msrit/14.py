first = float(input("Enter first value:- "))
second = float(input("Enter second value:- "))
print("The answer is {:.6f}".format(first/second))
