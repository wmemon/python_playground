passwd = {'rahul': 'genius', 'kumar': 'smart', 'ankita':'intelligent' }
print(f"The items in the dictionary are:- {passwd.items()} ")
print(f"The keys in the dictionary are:- {passwd.keys()}")
print(f"The values in the dictionary are:- {passwd.values()}")
print(passwd['kumar'])
passwd['ankita']='brilliant'
print(passwd.items())
