celsius_temperature = float(input("Please enter the temperature in Celsius:- "))
print(f"The temperature in Fahrenheit is {(celsius_temperature*(9/5))+32}")
